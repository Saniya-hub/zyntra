import React from 'react'
import { NavLink ,useLocation } from 'react-router-dom'
import logo from '../assets/images/logo.jpeg'

const Navbarr = () => {

    let navigate = useLocation();
    let pathBool = location.pathname.startsWith(`/adminportal`)
    return (
        <div className='navbar'>
            <div className="logo">
                <img src={logo} alt="" />
            </div>
            <div className='links'>
                
                    {pathBool
                        ?
                        // adminnav Bar
                        <ul>
                            <li><NavLink to='/AdminPortal/'>Home</NavLink></li>
                            <li><NavLink to='/AdminPortal/products'>Products</NavLink></li>
                            <li><NavLink to='/adminportal/addusers'>Add User</NavLink></li>
                            <li><NavLink to='/'>Logout</NavLink></li>
                        </ul>
                        :
                        // users navbar
                        <ul>
                            <li><NavLink to='/userportal/'>Home</NavLink></li>
                            <li><NavLink to='/userportal/About'>About</NavLink></li>
                            <li><NavLink to='/userportal/Products'>Products</NavLink></li>
                            <li><NavLink to='/userportal/cartitems'>Cart Items</NavLink> </li>
                            <li><NavLink to='/'>Logout</NavLink></li>
                        </ul>

                    }
                </div>
            </div>

        
    );

}



export default Navbarr



