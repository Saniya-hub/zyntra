import React from 'react'
import logo2 from '../assets/images/logo2.jpeg'
import facebook1 from '../assets/images/facebook1.png'
import youtube from '../assets/images/youtube.png'
import twitter from '../assets/images/twitter.png'
import insta1 from '../assets/images/insta1.png'
import { NavLink } from 'react-router-dom'

const Footer = () => {
  return (
    <>
    <div className="footer">
        <div className="footlogo">
            <img src={logo2} alt="" />
            <p>Shop more, live better with Zyntra.</p>
            <ul>
                <li><NavLink><img src={facebook1} alt="" /></NavLink></li>
                <li><NavLink><img src={youtube} alt="" /></NavLink></li>
                <li><NavLink><img src={twitter} alt="" /></NavLink></li>
                <li><NavLink><img src={insta1} alt="" /></NavLink></li>
            </ul>
        </div>
        <div className="foot-contact">
            <input type="text" placeholder='Enter Your email' />
            <button>SUBSCRIBE</button>
        </div>

        <div className="foot">
            <p>2026 Zyntra. All Rights Reserved</p>
        </div>

        
    </div>
    </>
  )
}

export default Footer
